#include<iostream>
using namespace std;
int main()
{
    int a[5]={10,15,16,17,18};
    cout<<a[1]<<endl;






    return 0;
}
