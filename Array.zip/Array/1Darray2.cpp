#include<iostream>
using namespace std;
int main()
{
    int n;
    cout<<"Enter the total toppers students number: "<<endl;
    cin>>n;
    char a[n];
    cout<<"Enter the topper students first name char: "<<endl;

    for(char i=0;i<n;i++)
    {
        cin>>a[i];
    }
    for(char i=0;i<n;i++)
    {
        cout<<"The toppers students name is: "<<a[i]<<endl;
    }



    return 0;
}
