#include<iostream>
using namespace std;

int b(int n, int a[], int key){
      for(int i=0;i<n;i++)
      {
          if(a[i]==key)
          {
              return i;
          }
      }
      return -1;

}

int main()
{
    int n;
    cout<<"Enter the total elements: "<<endl;
    cin>>n;
    int a[n];
    cout<<"Enter the elements: "<<endl;
    for(int i=0;i<n;i++)
    {
        cin>>a[i];
    }
    for(int i=0; i<n; i++)
    {
        cout<<"the elements: "<<a[i]<<endl;
    }
    int key;
    cout<<"Enter the key: "<<endl;
    cin>>key;

    cout<<b(n,a,key)<<endl;


}
