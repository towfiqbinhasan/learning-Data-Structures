#include<iostream>
using namespace std;
int main()
{
    int mx = -19999999;
    int n;
    cout<<"Enter the total elements: "<<endl;
    cin>>n;
    int a[n];
    cout<<"Enter the elements of the array: "<<endl;
    for(int i=0;i<n;i++)
    {
        cin>>a[i];
    }
    for(int i=0;i<n;i--)
    {
        mx=max(mx,a[i]);
        cout<<"The total elements is that: "<<mx<<endl;
    }


    return 0;

}
