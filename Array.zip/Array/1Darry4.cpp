#include<iostream>
using namespace std;
int main()
{
    int n;
    cout<<"Enter the total elements: "<<endl;\
    cin>>n;
    int a[n];
    cout<<"Enter the elements: "<<endl;
    for(int i=0; i<n; i++)
    {
        cin>>a[n];
    }
    for(int i=0; i<n-1;i++)
    {
        for(int j=i+1;j<n;j++)
        {

            if(a[j]<a[i])
            {
                int temp=a[j];
                a[j]=a[i];
                a[i]=temp;
            }

        }
    }
    for(int i=0;i<n;i++)
        {
            cout<<a[n]<<"   ";
        }
        cout<<endl;




    return 0;
}
