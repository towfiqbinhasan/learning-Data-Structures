#include<iostream>
using namespace std;
int main()
{
    int a,b;
    cout<<"Enter the size of the array is: "<<endl;
    cin>>a>>b;
    int arr[a][b];
    cout<<"Enter the elements of this array is: "<<endl;
    for(int i=0;i<a;i++)
    {
        for(int j=0;j<b;j++)
        {
            cin>>arr[i][j];
        }
    }
    for(int i=0;i<a;i++)
    {
        for(int j=0;j<b;j++)
        {
            cout<<"The elements of this matrix is that: "<<arr[i][j]<<endl;
        }
    }
    return 0;
}
