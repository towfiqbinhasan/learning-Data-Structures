#include<iostream>
using namespace std;
int main()
{
    int a[100]={50,55,45,47,41},p,i;
    cout<<"Enter the elements of this Array: "<<endl;
    cin>>p;
    for(int i=p;i<5;i=i+1)
    {
        a[i]=a[i+1];

    }
    for(int i=0;i<4;i=i+1){
        cout<<a[i]<<endl;
    }



    return 0;
}
