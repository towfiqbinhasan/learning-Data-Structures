#include<iostream>
using namespace std;
int main()
{
    int n,p,i;
    cout<<"Enter the size of this array: "<<endl;
    cin>>n;
    int a[n];
    cout<<"Enter the elements of this array: "<<endl;
    for(int i=0;i<n;i++)
    {
        cin>>a[i];
    }
    cout<<"Enter the deteling position of this array: "<<endl;
    cin>>p;
    for(int i=p;i<n;i=i+1)
    {
        a[i]=a[i+1];
    }
    for(int i=0;i<n-2;i=i+1)
    {
        cout<<"The result is: "<<a[i]<<endl;
    }
    return 0;
}
