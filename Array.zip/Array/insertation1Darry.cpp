#include<iostream>
using namespace std;
int main()
{
    int a[100]={5,55,85,78,45};
    int p,num,i;
    cout<<"Enter the elements: "<<endl;
    cin>>p>>num;
    for(int i=4; i>=p;i--){
        a[i+1]=a[i];
        a[p]=num;
    }
        cout<<"New array is : "<<endl;
        for(int i=0; i<6;i=i+1)
        {
            cout<<a[i]<<endl;
        }
        return 0;
}
