#include<iostream>
using namespace std;
int main()
{
    int n;
    cout<<"Enter the size of array: "<<endl;
    cin>>n;
    int a[n];
    cout<<"Enter the elements of this array: "<<endl;
    for(int i=0;i<n;i++)
    {
        cin>>a[i];
    }
    int p,num,i;
    cout<<"Enter the position and number change of this array: "<<endl;
    cin>>p>>num;
    for(int i=n;i>=p;i--)
    {
        a[i+1]=a[i];
        a[p]=num;
    }
    cout<<"The result is: "<<endl;
    for(int i=0;i<n+2;i=i+1)
    {
        cout<<a[i]<<endl;
    }
    return 0;
}
