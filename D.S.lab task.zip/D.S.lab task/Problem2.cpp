#include<iostream>
using namespace std;
int main()
{
    int arr[10] = {12,32,43,1,54,53,15,64,3,13};
    int o=0, e=0;


    for(int i=0;i<10;i++)
    {



    if(arr[i]%2==0)
    {
      e++;
    }
    else if(arr[i]%2!=0)
    {
     o++;
    }
    }
    cout<<"The value is odd: "<<o<<endl;
    cout<<"The value is even: "<<e<<endl;
    return 0;
}
