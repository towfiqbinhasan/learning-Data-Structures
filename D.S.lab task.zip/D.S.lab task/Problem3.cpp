#include<iostream>
using namespace std;
int main()
{
    {
        int numba[10]={1,2,3,4,5,6,7,8,9,10};
        for(int i=0;i<10;++i)
        {

            int j;
            int k;
            cout<<"Give lower Range"<<endl;
            cin>>j;
            cout<<"Give Higer Range"<<endl;
            cin>>k;
            for(i=j;i<k;++i)
            {

                if(numba[i]%2==0)
                   {

                       cout<<"Skip"<<endl;
                   }

             else {
                cout<<numba[i]<<"Is a an odd number"<<endl;
            }

        }
    }

    }


    return 0;

}
