#include<iostream>
using namespace std;
int factorial(int n)
{
    int fact=1;
    for(int i=2;i<=n;i++)
    {
        fact=fact*i;
    }
    return fact;
}
int main()
{
    int num;
    cout<<"Enter any Number : ";
    cin>>num;
    bool p=true;
    for(int i=2;i<num;i++)
    {
        if(num%i==0)
        {
            p=false;
            break;
        }
    }
    if(p)
    {
        int result=factorial(num);
        cout<<"Factorial of the entered number : "<<result<<endl;
    }
    else
    {
        cout<<"Error! Not a Prime Number"<<endl;
    }
    return 0;
}
