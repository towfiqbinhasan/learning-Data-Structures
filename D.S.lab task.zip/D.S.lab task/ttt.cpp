#include<iostream>
using namespace std;

int main()
{
    string a;
    cout<<"Enter your name: "<<endl;
    cin>>a;

  string students[3][4]=
  {
      {
          "22-48732-3","MD. Towfiq Bin Hasan", "3.98","towfiqbinhasan@gmail.com"
      },
      {
          "22-48755-3","MD.X","3.55","X@gmail.com"
      },
      {
          "22-48722-3","MD.Y","3.64","Y@gmail.com"
      }
  };
  cout<<"Students Detalis: "<<endl;

  for(int i=0;i<3;i++)
  {
      for(int j=0;j<4;j++)
      {
          cout<<students[i][j]<<"  "<<endl;
      }
      cout<<endl;
  }
    return 0;
}
