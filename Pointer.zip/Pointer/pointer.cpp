#include<iostream>
using namespace std;
int main()
{
   int a=10;
  // int ptr;
   int *ptr;
    ptr=&a;
    cout<<"The value of address is: "<<a<<*(&a)<<*ptr<<"\n";
    cout<<"addrese: "<<*(&a)<<*ptr<<endl;
    cout<<"acas"<<*ptr<<endl;
    (*ptr)++;
    cout<<a;




    return 0;
}






