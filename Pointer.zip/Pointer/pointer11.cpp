#include<iostream>
using namespace std;
int main()
{
    int n=10;
    int *ptr=&n;
    cout<<*ptr<<endl;
    *ptr=20;
    cout<<n<<endl;


    return 0;
}
