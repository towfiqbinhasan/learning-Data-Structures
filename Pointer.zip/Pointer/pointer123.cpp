#include<iostream>
using namespace std;
int main()
{
    int n=10;
    int *ptr;
    ptr=&n;
    cout<<*ptr<<endl;
    int *q=&ptr;
    cout<<*q<<endl;
   cout<<**q<<endl;
    return 0;
}
