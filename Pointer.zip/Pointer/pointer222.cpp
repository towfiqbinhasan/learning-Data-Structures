#include<iostream>
using namespace std;
int main()
{
    int n[10]={1,2,3,4,5,6,7,8,9,10};
    int *ptr=n;
    cout<<*ptr<<endl;
    for(int i=0;i<10;i++)
    {
        cout<<*ptr<<endl;
        *ptr++;
    }



    return 0;
}
