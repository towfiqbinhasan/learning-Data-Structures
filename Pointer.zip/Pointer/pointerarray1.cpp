#include<iostream>
using namespace std;
int main()
{
    int a[5]={12,13,14,15,16};
    int *ptr[5];
    for(int i=0;i<5;i=i+1)
    {
        ptr[i]=&a[i];

    }
    cout<<"values: "<<endl;

    for(int i=0;i<5;i=i+1)
    {
        cout<<*ptr[i]<<endl;
    }
cout<<endl;
    return 0;
}
