#include<iostream>
using namespace std;
int main()
{
    int a[5]={10,12,13,14,15};
    cout<<a<<endl;
  //  int i;
    int *ptr=a;
    for(int i=0;i<5;i++)
    {        cout<<*a<<endl;
        ptr++;
    }
    cout<<endl;





    return 0;
}
