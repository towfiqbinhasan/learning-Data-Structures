#include<iostream>
#include<string>
using namespace std;
int main()
{
    string a,b;
    string m;
    cout<<"Enter the size of this array: "<<endl;
    cin>>a>>b;
    string m[a][b];
    cout<<"Enter the elements of this array: "<<endl;
    for(int i=0;i<a;i++)
    {
        for(int j=0;j<b;j++)
        {
            cin>>m[i][j];
        }
    }
    for(int i=0;i<a;i++)
    {
        for(int j=0;j<b;j++)
        {
            cout<<"The elements is: "<<m[i][j]<<endl;
        }
    }
    cout<<endl;


    return 0;
}
