#include<iostream>
using namespace std;
int main()
{
    string a;
    int n;
    cout<<"Hello Mr/Mrs welcome to our company"<<endl;
    cout<<"Enter your ID: "<<endl;
    cin>>a;
    cout<<"Your team member detalis: "<<endl;
    string b[3][4]=
    {
     {
        "22-48732-3","MD.Towfiq Bin Hasan","CSE","AIUB"
     },
     {
       "22-48721-3","MD.Sadman sakih","CSE","RUET"
     },
     {
         "22-48752-3","MD. Nafis sasohn","CSE","BUET"
     }
     };
     for(int i=0;i<3;i++){
        for(int j=0;j<4;j++)
     {
         cout<<b[i][j]<<"  "<<endl;
     } } cout<<endl;

    return 0;
}
